<?php
// ============================================
// Адмін-панель — управління матеріалами
// Захист: простий пароль (для навчального проекту)
// ============================================
session_start();

$admin_password = 'admin123'; // змініть на свій пароль

// Авторизація
if (isset($_POST['login_pass'])) {
    if ($_POST['login_pass'] === $admin_password) {
        $_SESSION['admin'] = true;
    } else {
        $login_error = 'Невірний пароль.';
    }
}

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: admin/index.php');
    exit;
}

require '../config.php';

// CRUD операції
if (isset($_SESSION['admin'])) {

    // Видалення
    if (isset($_GET['delete'])) {
        $id = (int)$_GET['delete'];
        $conn->query("DELETE FROM mydata WHERE id = $id");
        header('Location: index.php');
        exit;
    }

    // Додавання / редагування
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save'])) {
        $name     = trim($conn->real_escape_string($_POST['name']     ?? ''));
        $opisanie = trim($conn->real_escape_string($_POST['opisanie'] ?? ''));
        $img      = trim($conn->real_escape_string($_POST['img']      ?? ''));
        $price    = (float)($_POST['price'] ?? 0);
        $id       = (int)($_POST['id']      ?? 0);

        if ($id > 0) {
            $conn->query("UPDATE mydata SET name='$name', opisanie='$opisanie',
                          img='$img', price=$price WHERE id=$id");
        } else {
            $conn->query("INSERT INTO mydata (name,opisanie,img,price)
                          VALUES ('$name','$opisanie','$img',$price)");
        }
        header('Location: index.php');
        exit;
    }

    // Отримання запису для редагування
    $edit_row = null;
    if (isset($_GET['edit'])) {
        $id = (int)$_GET['edit'];
        $r  = $conn->query("SELECT * FROM mydata WHERE id=$id");
        $edit_row = $r->fetch_assoc();
    }
}
?>
<!DOCTYPE html>
<html lang="uk">
<head>
  <meta charset="UTF-8">
  <title>Адмін-панель — АнтикорЦентр</title>
  <link rel="stylesheet" href="../css/style.css">
  <style>
    body { background:#f0f0f0; }
    .admin-wrap { max-width:900px; margin:40px auto; padding:0 20px; }
    .admin-card { background:#fff; border-radius:6px; padding:28px; margin-bottom:24px;
                  border:1px solid #ddd; }
    .admin-card h2 { color:#1a1a2e; margin-bottom:20px; font-size:18px; }
    .form-group { margin-bottom:14px; }
    .form-group label { display:block; font-weight:600; font-size:13px;
                        margin-bottom:5px; color:#555; }
    .form-group input, .form-group textarea {
        width:100%; padding:9px 12px; border:1px solid #ccc;
        border-radius:4px; font-size:14px; }
    .form-group textarea { height:90px; resize:vertical; }
    .login-box { max-width:360px; margin:100px auto; }
  </style>
</head>
<body>

<?php if (!isset($_SESSION['admin'])): ?>
<!-- Форма входу -->
<div class="login-box admin-card">
  <h2>🔐 Вхід в адмін-панель</h2>
  <?php if(isset($login_error)): ?>
    <p style="color:red;margin-bottom:12px;"><?= $login_error ?></p>
  <?php endif; ?>
  <form method="POST">
    <div class="form-group">
      <label>Пароль</label>
      <input type="password" name="login_pass" required autofocus>
    </div>
    <button type="submit" class="btn">Увійти</button>
  </form>
</div>

<?php else: ?>
<!-- Панель управління -->
<div class="admin-wrap">

  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
    <h1 style="color:#1a1a2e;font-size:20px;">⚙️ Адмін-панель — Матеріали</h1>
    <div>
      <a href="../index.php" class="btn" style="background:#1a1a2e;color:#e8b923;margin-right:8px;">← На сайт</a>
      <a href="?logout=1" class="btn" style="background:#e74c3c;">Вийти</a>
    </div>
  </div>

  <!-- Форма додавання / редагування -->
  <div class="admin-card">
    <h2><?= $edit_row ? '✏️ Редагувати матеріал' : '➕ Додати матеріал' ?></h2>
    <form method="POST">
      <input type="hidden" name="id" value="<?= $edit_row['id'] ?? 0 ?>">
      <div class="form-group">
        <label>Назва матеріалу</label>
        <input type="text" name="name" required
               value="<?= htmlspecialchars($edit_row['name'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label>Опис</label>
        <textarea name="opisanie"><?= htmlspecialchars($edit_row['opisanie'] ?? '') ?></textarea>
      </div>
      <div class="form-group">
        <label>Шлях до зображення (напр. image/dinitrol.jpg)</label>
        <input type="text" name="img"
               value="<?= htmlspecialchars($edit_row['img'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label>Ціна (грн)</label>
        <input type="number" name="price" step="0.01" required
               value="<?= $edit_row['price'] ?? '' ?>">
      </div>
      <button type="submit" name="save" class="btn">
        <?= $edit_row ? 'Зберегти зміни' : 'Додати' ?>
      </button>
      <?php if ($edit_row): ?>
        <a href="index.php" class="btn" style="background:#888;margin-left:10px;">Скасувати</a>
      <?php endif; ?>
    </form>
  </div>

  <!-- Таблиця матеріалів -->
  <div class="admin-card">
    <h2>📋 Список матеріалів</h2>
    <?php
    $rows = $conn->query("SELECT * FROM mydata ORDER BY id");
    if ($rows && $rows->num_rows > 0):
    ?>
    <table class="admin-table">
      <thead>
        <tr>
          <th>ID</th>
          <th>Назва</th>
          <th>Ціна</th>
          <th>Зображення</th>
          <th>Дії</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $rows->fetch_assoc()): ?>
        <tr>
          <td><?= $row['id'] ?></td>
          <td><?= htmlspecialchars($row['name']) ?></td>
          <td><?= number_format($row['price'], 0, '.', ' ') ?> грн</td>
          <td style="font-size:12px;color:#888;"><?= htmlspecialchars($row['img']) ?></td>
          <td>
            <a href="?edit=<?= $row['id'] ?>" class="btn-edit">✏️ Редагувати</a>
            <a href="?delete=<?= $row['id'] ?>"
               class="btn-delete"
               onclick="return confirm('Видалити «<?= htmlspecialchars($row['name']) ?>»?')">
              🗑 Видалити
            </a>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
    <?php else: ?>
      <p style="color:#888;">Матеріалів ще немає. Додайте перший запис вище.</p>
    <?php endif; ?>
  </div>

  <!-- Заявки від клієнтів -->
  <div class="admin-card">
    <h2>📩 Заявки від клієнтів</h2>
    <?php
    $reqs = $conn->query("SELECT * FROM requests ORDER BY created_at DESC LIMIT 50");
    if ($reqs && $reqs->num_rows > 0):
    ?>
    <table class="admin-table">
      <thead>
        <tr>
          <th>№</th><th>Ім'я</th><th>Телефон</th><th>Повідомлення</th><th>Дата</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($req = $reqs->fetch_assoc()): ?>
        <tr>
          <td><?= $req['id'] ?></td>
          <td><?= htmlspecialchars($req['first_name']) ?></td>
          <td><strong><?= htmlspecialchars($req['phone']) ?></strong></td>
          <td><?= htmlspecialchars($req['message']) ?></td>
          <td style="font-size:12px;color:#888;">
            <?= date('d.m.Y H:i', strtotime($req['created_at'])) ?>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
    <?php else: ?>
      <p style="color:#888;">Заявок ще немає.</p>
    <?php endif; ?>
  </div>

</div>
<?php endif; ?>

</body>
</html>
