<?php
$meta_title = 'Контакти — антикорозійна обробка авто в Києві | АнтикорЦентр';
$meta_desc  = 'Контакти автосервісу АнтикорЦентр у Києві. Адреса, телефон, форма зворотного зв\'язку. Залиште заявку — передзвонимо протягом 15 хвилин.';
$meta_keys  = 'антикор Київ контакти, автосервіс антикор Київ адреса, залишити заявку антикор';
require 'includes/header.php';
require 'config.php';

$success = false;
$errors  = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = trim(strip_tags($_POST['first_name'] ?? ''));
    $phone      = trim(strip_tags($_POST['phone']      ?? ''));
    $message    = trim(strip_tags($_POST['message']    ?? ''));

    // Валідація
    if (empty($phone)) {
        $errors[] = 'Номер телефону є обов\'язковим.';
    } elseif (!preg_match('/^[\d\s\+\(\)\-]{7,20}$/', $phone)) {
        $errors[] = 'Введіть коректний номер телефону.';
    }

    if (empty($errors)) {
        // Зберігаємо у БД
        $stmt = $conn->prepare(
            "INSERT INTO requests (first_name, phone, message) VALUES (?, ?, ?)"
        );
        $stmt->bind_param('sss', $first_name, $phone, $message);
        $stmt->execute();
        $stmt->close();

        // Надсилаємо email
        $to      = ADMIN_EMAIL;
        $subject = 'Нова заявка з сайту АнтикорЦентр';
        $body    = "Нова заявка з веб-сайту:\n\n"
                 . "Ім'я: {$first_name}\n"
                 . "Телефон: {$phone}\n"
                 . "Повідомлення: {$message}\n"
                 . "Час: " . date('d.m.Y H:i');
        $headers = 'From: noreply@auto-antikor.com.ua';
        @mail($to, $subject, $body, $headers);

        $success = true;
    }
}
?>

<div class="hero" style="padding:30px 20px;">
  <div class="container">
    <h1>Контакти та зворотній зв'язок</h1>
    <p>Залиште заявку — передзвонимо протягом 15 хвилин</p>
  </div>
</div>

<section>
  <div class="container">
    <h2>Зв'яжіться з нами</h2>
    <div class="contact-grid">

      <!-- Форма -->
      <div>
        <?php if ($success): ?>
          <div class="alert-success">
            ✅ Дякуємо! Вашу заявку отримано. Ми зателефонуємо вам найближчим часом.
          </div>
        <?php endif; ?>

        <?php if (!empty($errors)): ?>
          <div style="background:#f8d7da;color:#721c24;padding:12px 16px;border-radius:4px;margin-bottom:16px;font-size:14px;">
            <?php foreach($errors as $e): ?>
              <p>⚠️ <?= htmlspecialchars($e) ?></p>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>

        <form class="contact-form" method="POST" action="contacts.php">
          <label style="font-weight:600;font-size:14px;color:#1a1a2e;display:block;margin-bottom:6px;">Напишіть нам</label>
          <input type="text"
                 name="first_name"
                 placeholder="Ваше ім'я"
                 value="<?= htmlspecialchars($_POST['first_name'] ?? '') ?>">
          <input type="tel"
                 name="phone"
                 placeholder="Ваш телефон (обов'язково)"
                 required
                 maxlength="20"
                 value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
          <textarea name="message"
                    placeholder="Ваше повідомлення або запитання"><?= htmlspecialchars($_POST['message'] ?? '') ?></textarea>
          <button type="submit" class="btn">Відправити</button>
        </form>
      </div>

      <!-- Контактні дані -->
      <div class="contact-info">
        <p><strong>📍 Адреса:</strong><br>м. Київ, вул. Транспортна, 6Б</p>
        <p><strong>📞 Телефон:</strong><br>+38 (097) 000-00-00</p>
        <p><strong>🕐 Режим роботи:</strong><br>Пн–Пт: 9:00–19:00<br>Сб: 9:00–17:00<br>Нд: вихідний</p>
        <p><strong>📧 Email:</strong><br>info@auto-antikor.com.ua</p>
        <p style="margin-top:20px;font-size:13px;color:#888;">
          Усі права захищено. <?= date('Y') ?> р.<br>
          При копіюванні матеріалів посилання на сайт обов'язкове.
        </p>
      </div>
    </div>
  </div>
</section>

<?php require 'includes/footer.php'; ?>
