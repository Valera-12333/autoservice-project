<?php
$meta_title = 'Матеріали для антикорозійної обробки авто — ціни | АнтикорЦентр';
$meta_desc  = 'Перелік антикорозійних матеріалів: Dinitrol, Tectyl, Мовіль, Master Wax. Характеристики, опис та ціни на склади для обробки кузова автомобіля в Києві.';
$meta_keys  = 'Dinitrol антикор, Tectyl авто, Мовіль обробка, Master Wax антикор, матеріали для антикору';
require 'includes/header.php';
require 'config.php';
?>

<div class="hero" style="padding:30px 20px;">
  <div class="container">
    <h1>Матеріали для антикорозійної обробки</h1>
    <p>Використовуємо лише перевірені склади від провідних виробників</p>
  </div>
</div>

<section>
  <div class="container">
    <h2>Прайс-лист матеріалів</h2>

    <?php
    $result = $conn->query("SELECT * FROM mydata ORDER BY id");
    if ($result && $result->num_rows > 0):
    ?>
    <table class="materials-table">
      <thead>
        <tr>
          <th>Фото</th>
          <th>Назва</th>
          <th>Опис</th>
          <th>Ціна за комплект</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
          <td>
            <img src="<?= htmlspecialchars($row['img']) ?>"
                 alt="<?= htmlspecialchars($row['name']) ?> антикорозійний склад"
                 title="<?= htmlspecialchars($row['name']) ?> — антикор матеріал"
                 onerror="this.src='image/placeholder.jpg'">
          </td>
          <td><strong><?= htmlspecialchars($row['name']) ?></strong></td>
          <td><?= htmlspecialchars($row['opisanie']) ?></td>
          <td><span class="price-tag"><?= number_format($row['price'], 0, '.', ' ') ?> грн</span></td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
    <?php else: ?>
      <p style="color:#888;">Матеріали не знайдено. Зверніться до адміністратора.</p>
    <?php endif; ?>

    <p style="margin-top:24px;color:#666;font-size:14px;">
      * Ціна вказана за один комплект обробки. Точна вартість розраховується індивідуально
      залежно від класу автомобіля та обраних зон обробки.
      <a href="total.php" style="color:#e8b923;font-weight:600;">Розрахувати вартість →</a>
    </p>
  </div>
</section>

<?php require 'includes/footer.php'; ?>
