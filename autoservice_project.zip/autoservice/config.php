<?php
// ============================================
// Налаштування підключення до бази даних
// Змініть параметри під свій хостинг
// ============================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');       // ваш логін MySQL
define('DB_PASS', '');           // ваш пароль MySQL
define('DB_NAME', 'autoservice');

// Email для отримання заявок
define('ADMIN_EMAIL', 'your@email.com');

// Підключення
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$conn->set_charset('utf8mb4');

if ($conn->connect_error) {
    die('Помилка підключення: ' . $conn->connect_error);
}
