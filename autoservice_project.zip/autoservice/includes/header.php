<?php
// Визначаємо поточну сторінку для підсвітки меню
$current = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="uk">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php if(isset($meta_title)): ?>
    <title><?= htmlspecialchars($meta_title) ?></title>
    <meta name="description" content="<?= htmlspecialchars($meta_desc) ?>">
    <meta name="keywords" content="<?= htmlspecialchars($meta_keys) ?>">
  <?php else: ?>
    <title>Антикорозійна обробка авто в Києві | АВТОСЕРВІС ПЛЮС</title>
  <?php endif; ?>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

<header>
  <div class="header-top">
    <div class="logo">Антикор<span>Центр</span></div>
    <div>
      <div class="header-phone">+38 (097) 000-00-00</div>
      <div class="header-badge">№ 1 в Києві • Пн-Сб 9:00–19:00</div>
    </div>
  </div>
  <nav>
    <ul>
      <li><a href="index.php"    <?= $current=='index.php'    ? 'class="active"':'' ?>>Головна</a></li>
      <li><a href="antikor.php"  <?= $current=='antikor.php'  ? 'class="active"':'' ?>>Антикор</a></li>
      <li><a href="tovary.php"   <?= $current=='tovary.php'   ? 'class="active"':'' ?>>Матеріали</a></li>
      <li><a href="total.php"    <?= $current=='total.php'    ? 'class="active"':'' ?>>Розрахунок вартості</a></li>
      <li><a href="contacts.php" <?= $current=='contacts.php' ? 'class="active"':'' ?>>Контакти</a></li>
    </ul>
  </nav>
</header>
