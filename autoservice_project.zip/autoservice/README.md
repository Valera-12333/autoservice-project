# Веб-сайт АнтикорЦентр — інструкція з встановлення

## Структура проекту

```
autoservice/
├── index.php          — Головна сторінка
├── antikor.php        — Сторінка «Антикор»
├── tovary.php         — Матеріали (прайс-лист)
├── total.php          — Калькулятор вартості
├── contacts.php       — Контакти + форма заявки
├── config.php         — Налаштування БД
├── database.sql       — SQL-скрипт бази даних
├── css/
│   └── style.css      — Стилі сайту
├── includes/
│   ├── header.php     — Шапка + навігація
│   └── footer.php     — Підвал
├── admin/
│   └── index.php      — Адмін-панель
│       пароль: admin123 (змініть у файлі)
└── image/             — Папка для зображень матеріалів
```

## Встановлення (XAMPP / OpenServer)

### Крок 1 — Скопіюйте файли
Скопіюйте всю папку `autoservice` до:
- XAMPP: `C:/xampp/htdocs/autoservice`
- OpenServer: `domains/autoservice`

### Крок 2 — Створіть базу даних
1. Відкрийте phpMyAdmin: http://localhost/phpmyadmin
2. Натисніть «Імпорт»
3. Виберіть файл `database.sql`
4. Натисніть «Вперед»

### Крок 3 — Налаштуйте config.php
Відкрийте `config.php` та вкажіть:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');       // ваш логін
define('DB_PASS', '');           // ваш пароль
define('DB_NAME', 'autoservice');
define('ADMIN_EMAIL', 'your@email.com');
```

### Крок 4 — Додайте зображення
Помістіть у папку `image/` такі файли:
- `dinitrol.jpg`
- `movil.jpg`
- `masterwax.jpg`
- `tectyl.jpg`
- `placeholder.jpg` (запасне зображення)

### Крок 5 — Відкрийте сайт
http://localhost/autoservice/

## Адмін-панель
http://localhost/autoservice/admin/
Пароль за замовчуванням: `admin123`
⚠️ Обов'язково змініть пароль у файлі `admin/index.php`

## Сторінки сайту
| Адреса | Опис |
|---|---|
| /index.php | Головна |
| /antikor.php | Про антикор |
| /tovary.php | Матеріали |
| /total.php | Калькулятор |
| /contacts.php | Контакти |
| /admin/ | Адмін-панель |
