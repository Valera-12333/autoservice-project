<?php
$meta_title = 'Розрахунок вартості антикорозійної обробки авто онлайн | АнтикорЦентр';
$meta_desc  = 'Онлайн калькулятор вартості антикорозійної обробки автомобіля в Києві. Оберіть клас авто, матеріал та зони обробки — отримайте орієнтовну ціну миттєво.';
$meta_keys  = 'вартість антикору авто, ціна антикорозійної обробки Київ, калькулятор антикор';
require 'includes/header.php';
require 'config.php';

// Отримуємо матеріали з БД для JS-масиву
$materials = [];
$res = $conn->query("SELECT id, name, price FROM mydata ORDER BY id");
while ($row = $res->fetch_assoc()) {
    $materials[] = $row;
}
?>

<div class="hero" style="padding:30px 20px;">
  <div class="container">
    <h1>Розрахунок вартості обробки</h1>
    <p>Оберіть параметри — вартість розрахується автоматично</p>
  </div>
</div>

<section>
  <div class="container">
    <h2>Калькулятор вартості</h2>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:40px;align-items:start;">

      <div class="calculator">

        <!-- Зони обробки -->
        <div class="calc-row">
          <label>Зони обробки:</label>
          <div class="checkbox-group">
            <label><input type="checkbox" id="zona_dnyshe" checked onchange="calcCost()"> Обробка днища</label>
            <label><input type="checkbox" id="zona_arky" onchange="calcCost()"> Обробка арок</label>
            <label><input type="checkbox" id="zona_porozhnyny" onchange="calcCost()"> Приховані порожнини</label>
          </div>
        </div>

        <!-- Матеріал -->
        <div class="calc-row">
          <label for="material">Матеріал:</label>
          <select id="material" onchange="calcCost()">
            <?php foreach ($materials as $m): ?>
            <option value="<?= $m['price'] ?>"><?= htmlspecialchars($m['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <!-- Клас авто -->
        <div class="calc-row">
          <label for="klass">Клас автомобіля:</label>
          <select id="klass" onchange="calcCost()">
            <option value="0.85">A — малолітражний (до 3.6 м)</option>
            <option value="1.00" selected>B — малий (3.6–4.2 м)</option>
            <option value="1.10">B1 — середній седан (4.2–4.6 м)</option>
            <option value="1.20">C — компакт (4.2–4.5 м)</option>
            <option value="1.35">D — середній клас (4.5–4.8 м)</option>
            <option value="1.50">E — бізнес-клас (4.8–5.0 м)</option>
            <option value="1.60">F — представницький (5.0+ м)</option>
            <option value="1.40">SUV / Кросовер</option>
            <option value="1.70">Позашляховик / Рамний</option>
          </select>
        </div>

        <!-- Мийка днища -->
        <div class="calc-row">
          <div class="checkbox-group">
            <label><input type="checkbox" id="myjka" onchange="calcCost()"> Мийка днища (+ 500 грн)</label>
          </div>
        </div>

        <!-- Результат -->
        <div class="result-box">
          Орієнтовна вартість: <span id="result">0</span> грн
        </div>

        <p style="margin-top:12px;font-size:13px;color:#888;">
          * Точна вартість визначається після огляду автомобіля майстром.
        </p>
      </div>

      <!-- Класи авто -->
      <div>
        <h3 style="margin-bottom:16px;color:#1a1a2e;">Класи автомобілів</h3>
        <table style="width:100%;border-collapse:collapse;font-size:13px;">
          <thead>
            <tr style="background:#1a1a2e;color:#e8b923;">
              <th style="padding:8px 12px;text-align:left;">Клас</th>
              <th style="padding:8px 12px;text-align:left;">Приклади</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $classes = [
              ['A','Daewoo Matiz, Ока, Smart'],
              ['B','Гранта, Приора, Nexia'],
              ['B1','Веста, Solaris, Rio'],
              ['C','Astra, Focus, Golf'],
              ['D','Camry, Passat, Accord'],
              ['E','E-Class, 5 Series, A6'],
              ['F','S-Class, 7 Series, A8'],
              ['SUV','RAV4, Tiguan, CX-5'],
              ['Рамний','Land Cruiser, Prado'],
            ];
            foreach($classes as $i=>[$cls,$ex]):
            $bg = $i%2===0 ? '#f9f9f9' : '#fff';
            ?>
            <tr style="background:<?=$bg?>">
              <td style="padding:8px 12px;font-weight:700;color:#1a1a2e;"><?=$cls?></td>
              <td style="padding:8px 12px;color:#555;"><?=$ex?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</section>

<script>
function calcCost() {
    const dnyshe     = document.getElementById('zona_dnyshe').checked     ? 0.5  : 0;
    const arky       = document.getElementById('zona_arky').checked       ? 0.25 : 0;
    const porozhnyny = document.getElementById('zona_porozhnyny').checked ? 0.35 : 0;
    const L          = dnyshe + arky + porozhnyny;

    const N     = parseFloat(document.getElementById('material').value) || 0;
    const K     = parseFloat(document.getElementById('klass').value)    || 1;
    const myjka = document.getElementById('myjka').checked ? 500 : 0;

    const S = Math.round(L * N * K + myjka);

    document.getElementById('result').textContent =
        S > 0 ? S.toLocaleString('uk-UA') : '0';
}
calcCost();
</script>

<?php require 'includes/footer.php'; ?>
